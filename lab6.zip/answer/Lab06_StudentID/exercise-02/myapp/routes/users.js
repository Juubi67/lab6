var express = require("express");
var bodyParser = require("body-parser");
var router = express.Router();

/* GET users listing. */
router.get("/", function (req, res, next) {
  res.send("respond with a resource");
});

/* POST user */
router.post("/", function (req, res, next) {
  const body = req.body;
  console.log("First name : ", body.firstname);
  console.log("Last name : ", body.lastname);
  res.send("POST received");
});

router.use(bodyParser.urlencoded({ extended: true }));

module.exports = router;
